package com.example.api_login01.utils;

public class PreferencesUtility {

    public static final String PREF_NAME = "com.example.api_login01";

//    LOGIN


    public static final String LOGGED_IN_PREF = "logged_in_status";
}
