package com.example.api_login01.utils;

public interface AppConstance {

    public static String APP_BASE_URL = "http://10.0.2.2:8001/";
}
